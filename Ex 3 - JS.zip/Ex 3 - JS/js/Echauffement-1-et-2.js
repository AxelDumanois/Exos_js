var prenom = prompt("Entrez votre prénom :");
var nom = prompt("Entrez votre nom : ");

alert("Bonjour, " + prenom + " " + nom);

var question1 = prompt("Quelle est la couleur du cheval blanc d'Henri IV?");

switch (question1) {
	case "blanche" :
		console.log("Quel talent! Vous avez trouvé la réponse!");
		break;
		default: console.log("Quel dommage! Vous n'avez pas trouvé!");
}

var question2 = prompt("Combien y a-t-il de 7 nains?")

switch (question2) {
	case "1" :
		console.log("Quel talent! Vous avez trouvé la réponse!");
		break;
		default: console.log("Quel dommage! Vous n'avez pas trouvé!");
}



