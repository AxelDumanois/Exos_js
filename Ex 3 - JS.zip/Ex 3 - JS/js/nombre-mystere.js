function nbAleatoire (min, max)
{
	var nb = min + (max-min+1)*Math.random();
	return Math.floor(nb);
}

var nb = nbAleatoire(1, 9);

var saisie;
var msg = "Le nombre saisi est entre 0 et 9"

do {
	saisie = prompt(msg);

}

while (saisie != nb);{
		if(saisie > nb)
		msg = "c'est moins";
	else
		msg = "c'est plus";


}


