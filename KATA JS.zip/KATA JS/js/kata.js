
console.log("Bienvenue en ...")

/*Fonction masquée*/

function masquer (name) {

    console.log("*".repeat(name.length - 4) + name.slice(-4));
}

masquer('AxelDumanoismdrmdrmdr'); 

console.log("Et oui! Bienvenue en JS!")

/*Fonction coercition*/

function main(A, B) {
    A = typeof A;
    B = typeof B;

    if (A == B) {
        console.log("Identique");
    } else {
        console.log("Différent");
    }

}
main(2, "True");


/*Fonction MaxMin*/

function maxEtMin(numbers) {
    numbers = numbers.split(" ");
    return Math.max.apply(null, numbers) + " " + Math.min.apply(null, numbers)
}

console.log(maxEtMin("-1 -2 -3 -4 -5"));


/*Fonction nombre unique*/

function nombreUnique(arr) {
    return arr.filter(function(value) {
        return arr.indexOf(value) === arr.lastIndexOf(value);
    })[0] || -1;
}

var A = [22, 25, 3, 3, 1, 2, 0, 0, 100, 22, 25, 1, 2];
console.log(nombreUnique(A));


/*Fonction unique string */

function extractMiddle(str) {
    var result;
    var position;
    var length;

    if (str.length % 2 == 1) {
        position = str.length / 2;
        length = 1;
    } else {
        position = str.length / 2 - 1;
        length = 2;
    }
    result = str.substring(position, position + length)
    return (result);
}
console.log(extractMiddle("pourquo42ilavie?"));